//
//  ViewController.swift
//  Evidencia-temperatura
//
//  Created by Alumno on 9/3/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTemperatura: UILabel!
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var lblNombreResultado: UILabel!
    @IBOutlet weak var sldTemperatura: UISlider!
    @IBOutlet weak var btnCapturaVisitante: UIButton!
    @IBOutlet weak var btnCapturaVisitanteNuevo: UIButton!
    @IBOutlet weak var imgResultante: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        imgResultante.isHidden = true
        lblNombreResultado.isHidden = true
        btnCapturaVisitanteNuevo.isHidden = true
        btnCapturaVisitante.isEnabled = true
        sldTemperatura.isEnabled = true
    }

    @IBAction func doChangeSldTemperatura(_ sender: Any) {
        lblTemperatura.text = "\(String(format: "%.1f", sldTemperatura.value))C°"
        if sldTemperatura.value >= 38.0 {
            lblTemperatura.textColor = UIColor.red
        }else{
            lblTemperatura.textColor = UIColor.black
        }
    }
    
    @IBAction func DoTapCapturar(_ sender: Any) {
        if sldTemperatura.value >= 38.0 {
            imgResultante.image = UIImage(named: "prihibido")
            lblNombreResultado.text = "Acceso no autorizado para \(txtNombre.text!)"
        }else{
            imgResultante.image = UIImage(named: "paloma")
            lblNombreResultado.text = "Acceso autorizado para \(txtNombre.text!)"
        }
        
        imgResultante.isHidden = false
        lblNombreResultado.isHidden = false
        btnCapturaVisitanteNuevo.isHidden = false
        btnCapturaVisitante.isEnabled = false
        sldTemperatura.isEnabled = false
        sldTemperatura.tintColor = UIColor.gray
    }
    
    
    @IBAction func DoTapNuevo(_ sender: Any) {
        imgResultante.isHidden = true
        lblNombreResultado.isHidden = true
        btnCapturaVisitanteNuevo.isHidden = true
        btnCapturaVisitante.isEnabled = true
        sldTemperatura.isEnabled = true
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

